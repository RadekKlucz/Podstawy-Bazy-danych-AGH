IF OBJECT_ID('Dodaj_Konferencje') IS NOT NULL 
DROP PROC Dodaj_Konferencje;
GO
IF OBJECT_ID('Dodaj_Dzien_Konferencji') IS NOT NULL 
DROP PROC Dodaj_Dzien_Konferencji;
GO
IF OBJECT_ID('Dodaj_Warsztat') IS NOT NULL 
DROP PROC Dodaj_Warsztat;
GO
IF OBJECT_ID('Dodaj_Klienta') IS NOT NULL 
DROP PROC Dodaj_Klienta;
GO
IF OBJECT_ID('Dodaj_Uczestnika') IS NOT NULL 
DROP PROC Dodaj_Uczestnika;
GO
IF OBJECT_ID('Dodaj_Rezerwacje_Dnia') IS NOT NULL
DROP PROC Dodaj_Rezerwacje_Dnia
GO
IF OBJECT_ID('Dodaj_Rezerwacje_Warsztatu') IS NOT NULL
DROP PROC Dodaj_Rezerwacje_Warsztatu
GO
IF OBJECT_ID('Dodaj_Rejestracje_Dnia') IS NOT NULL
DROP PROC Dodaj_Rejestracje_Dnia
GO
IF OBJECT_ID('Dodaj_Rejestracje_Warsztatu') IS NOT NULL
DROP PROC Dodaj_Rejestracje_Warsztatu
GO


CREATE PROCEDURE Dodaj_Konferencje
	@Nazwa varchar(50),
	@Miasto varchar(50),
	@Ulica varchar(50),
	@Nr_Budynku int,
	@Kod_Pocztowy varchar(50)
	AS 
	BEGIN
		SET NOCOUNT ON;
		INSERT INTO Konferencje
		(Nazwa, Miasto, Ulica, Nr_Budynku, Kod_Pocztowy) 
		VALUES (@Nazwa, @Miasto, @Ulica, @Nr_Budynku, @Kod_Pocztowy)
	END
GO

CREATE PROCEDURE Dodaj_Dzien_Konferencji
	@Nazwa_Konferencji varchar(50),
	@Data date,
	@Cena_Bazowa money,
	@Znizka_Studencka int,
	@Liczba_Miejsc int
	AS
	BEGIN
		SET NOCOUNT ON;
		DECLARE @ID_Konf AS int
		SET @ID_Konf = (
			SELECT ID_Konferencji 
			FROM Konferencje
			WHERE Nazwa = @Nazwa_Konferencji		
		)
		INSERT INTO Dni_Konferencji
		(ID_Konferencji, Data, Cena_bazowa, Znizka_Studencka, Liczba_miejsc)
		VALUES (@ID_Konf, @Data, @Cena_Bazowa, @Znizka_Studencka, @Liczba_Miejsc)
	END
GO

CREATE PROCEDURE Dodaj_Warsztat
	@Nazwa_Konf varchar(50),
	@Data date,
	@Temat varchar(50),
	@Cena money,
	@Liczba_miejsc int,
	@Godzina_Rozpoczecia time,
	@Godzina_Zakonczenia time
	AS
	BEGIN
		SET NOCOUNT ON;
		DECLARE @ID_Dnia AS int
		SET @ID_Dnia = dbo.Pobierz_ID_Dnia(@Nazwa_Konf, @Data)
		INSERT INTO Warsztaty
		(ID_Dnia_Konferencji, Temat, Liczba_miejsc, Cena, Godzina_Rozpoczecia, Godzina_Zakonczenia)
		VALUES (@ID_Dnia, @Temat, @Liczba_miejsc, @Cena, @Godzina_Rozpoczecia, @Godzina_Zakonczenia)
	END
GO

CREATE PROCEDURE Dodaj_Klienta
	@Nazwa varchar(50),
	@NIP char(10),
	@Nr_Telefonu varchar(15),
	@Miasto varchar(50),
	@Ulica varchar(50),
	@Kod_Pocztowy varchar(50),
	@Nr_Budynku int,
	@Nr_Lokalu int = null,
	@Nr_Konta varchar(50) = null,
	@Email varchar(50) = null
	AS
	BEGIN
		SET NOCOUNT ON;
		INSERT INTO Klienci
		(Nazwa, NIP, Nr_telefonu, Miasto, Ulica, Kod_pocztowy, Nr_budynku, Nr_lokalu, Nr_konta, Email)
		VALUES (@Nazwa, @NIP, @Nr_Telefonu, @Miasto, @Ulica, @Kod_Pocztowy, @Nr_Budynku, @Nr_Lokalu, @Nr_Konta, @Email)
	END
GO

CREATE PROCEDURE Dodaj_Uczestnika
	@NIP_Klienta char(10),
	@PESEL char(11),
	@Imie varchar(50),
	@Nazwisko varchar(50),
	@Nr_Legitymacji int = null
	AS
	BEGIN
		SET NOCOUNT ON;
		INSERT INTO Uczestnicy
		(ID_Uczestnika, Imie, Nazwisko, NIP_Klienta, Nr_Legitymacji)
		VALUES (@PESEL, @Imie, @Nazwisko, @NIP_Klienta, @Nr_Legitymacji)
	END
GO

CREATE PROCEDURE Dodaj_Rezerwacje_Dnia
	@Nazwa_Konf varchar(50),
	@Data date,
	@NIP_Klienta char(10),
	@Liczba_Miejsc int
	AS
	BEGIN
		SET NOCOUNT ON;
		DECLARE @ID_Dnia AS int
		SET @ID_Dnia = dbo.Pobierz_ID_Dnia(@Nazwa_Konf, @Data)
		DECLARE @Znizka AS float
		SET @Znizka = 1 - DATEDIFF(WEEK, GETDATE(), @Data)/100
		IF (@Znizka < 0.9) BEGIN
			SET @Znizka = 0.9
		END
		DECLARE @Do_zaplaty money
		SET @Do_zaplaty = (
			SELECT Cena_bazowa
			FROM Dni_Konferencji
			WHERE ID_Dnia_Konferencji = @ID_Dnia
		) * @Liczba_Miejsc * @Znizka
		
		IF dbo.Dzien_Konferencji_Wolne_Miejsca(@ID_Dnia) >= @Liczba_Miejsc
		BEGIN
			INSERT INTO Dni_Konferencji_Rezerwacje
			(ID_Dnia_Konferencji, NIP_Klienta, Liczba_Miejsc, Kwota_do_zaplaty)
			VALUES (@ID_Dnia, @NIP_Klienta, @Liczba_Miejsc, @Do_zaplaty)
		END
	END
GO

CREATE PROCEDURE Dodaj_Rezerwacje_Warsztatu
	@Nazwa_Konf varchar(50),
	@Data date,
	@Temat varchar(50),
	@Liczba_Miejsc int,
	@NIP_Klienta char(10)
	AS
	BEGIN
		SET NOCOUNT ON;
		DECLARE @ID_War AS int
		SET @ID_War = dbo.Pobierz_ID_Warsztatu(@Nazwa_Konf, @Data, @Temat)
		
		DECLARE @Do_zaplaty money
		SET @Do_zaplaty = (
			SELECT Cena
			FROM Warsztaty
			WHERE ID_Warsztatu = @ID_War
		) * @Liczba_Miejsc
		
		IF dbo.Warsztat_Wolne_Miejsca(@ID_War) >= @Liczba_Miejsc
		BEGIN
			INSERT INTO Warsztaty_Rezerwacje
			(ID_Warsztatu, NIP_Klienta, Liczba_Miejsc, Kwota_do_zaplaty)
			VALUES (@ID_War, @NIP_Klienta, @Liczba_Miejsc, @Do_zaplaty)
		END
	END
GO

CREATE PROCEDURE Dodaj_Rejestracje_Dnia
	@NIP_Klienta varchar(50),
	@PESEL char(11),
	@Nazwa_Konf varchar(50),
	@Data date
	AS
	BEGIN
		SET NOCOUNT ON;	
		DECLARE @ID_Rez AS int
		SET @ID_Rez = (
			SELECT ID_Rezerwacji
			FROM Dni_Konferencji_Rezerwacje 
			WHERE ID_Dnia_Konferencji = dbo.Pobierz_ID_Dnia(@Nazwa_Konf, @Data) 
				AND NIP_Klienta = @NIP_Klienta
		)
		DECLARE @Data_Rezerwacji AS date
		SET @Data_Rezerwacji = (
			SELECT Data_Rezerwacji
			FROM Dni_Konferencji_Rezerwacje
			WHERE ID_Dnia_Konferencji = dbo.Pobierz_ID_Dnia(@Nazwa_Konf, @Data) 
			AND NIP_Klienta = @NIP_Klienta
		)
		
		DECLARE @Znizka1 AS float
		SET @Znizka1 = 1 - DATEDIFF(WEEK, @Data_Rezerwacji, @Data)/100
		IF (@Znizka1 < 0.9) BEGIN
			SET @Znizka1 = 0.9
		END
		
		DECLARE @Znizka2 AS float
		SET @Znizka2 = (
			SELECT COUNT(*)
			FROM Dni_Konferencji_Rejestracje JOIN Uczestnicy
			ON Dni_Konferencji_Rejestracje.ID_Uczestnika = Uczestnicy.ID_Uczestnika
			WHERE ID_Rezerwacji = @ID_Rez AND Nr_Legitymacji IS NOT NULL
		) / (SELECT Liczba_Miejsc FROM Dni_Konferencji_Rezerwacje WHERE ID_Rezerwacji = @ID_Rez)
		SET @Znizka2 = 1 - @Znizka2 * (
			SELECT Znizka_Studencka
			FROM Dni_Konferencji
			WHERE ID_Dnia_Konferencji = dbo.Pobierz_ID_Dnia(@Nazwa_Konf, @Data) 
		)
		
		IF dbo.Rezerwacja_Dnia_Wolne_Miejsca(@ID_Rez) > 0
		BEGIN 
			BEGIN TRANSACTION 
				INSERT INTO Dni_Konferencji_Rejestracje
				(ID_Rezerwacji, ID_Uczestnika)
				VALUES (@ID_Rez, @PESEL)
				
				IF @@ERROR <> 0
				BEGIN
					RAISERROR('error', 16, 1)
					ROLLBACK TRANSACTION
				END
				
				UPDATE Dni_Konferencji_Rezerwacje
				SET Kwota_Do_Zaplaty = (
					SELECT Liczba_Miejsc * (
						SELECT Cena_Bazowa
						FROM Dni_Konferencji
						WHERE ID_Dnia_Konferencji = dbo.Pobierz_ID_Dnia(@Nazwa_Konf, @Data)
					)
					FROM Dni_Konferencji_Rezerwacje
					WHERE ID_Rezerwacji = @ID_Rez
				) * @Znizka1 * @Znizka2
				WHERE ID_Rezerwacji = @ID_Rez
				
				IF @@ERROR <> 0
				BEGIN
					RAISERROR('error', 16, 1)
					ROLLBACK TRANSACTION
				END
			COMMIT TRANSACTION
		END
	END
GO

CREATE PROCEDURE Dodaj_Rejestracje_Warsztatu
	@NIP_Klienta char(10),
	@PESEL char(11),
	@Nazwa_Konf varchar(50),
	@Data date,
	@Temat varchar(50)
	AS
	BEGIN
		SET NOCOUNT ON;
		DECLARE @ID_Rez_War AS int
		SET @ID_Rez_War = (
			SELECT ID_Rezerwacji
			FROM Warsztaty_Rezerwacje 
			WHERE NIP_Klienta = @NIP_Klienta 
				AND ID_Warsztatu = dbo.Pobierz_ID_Warsztatu(@Nazwa_Konf, @Data, @Temat)
		)
		DECLARE @ID_Rej AS int 
		SET @ID_Rej = (
			SELECT ID_Rejestracji
			FROM Dni_Konferencji_Rejestracje
			WHERE ID_Uczestnika = @PESEL AND ID_Rezerwacji = (
				SELECT ID_Rezerwacji
				FROM Dni_Konferencji_Rezerwacje 
				WHERE NIP_Klienta = @NIP_Klienta 
					AND ID_Dnia_Konferencji = dbo.Pobierz_ID_Dnia(@Nazwa_Konf, @Data)
			)
		)
		DECLARE @Godzina_Rozpoczecia AS time
		SET @Godzina_Rozpoczecia = (
			SELECT Godzina_Rozpoczecia 
			FROM Warsztaty 
			WHERE ID_Warsztatu = dbo.Pobierz_ID_Warsztatu(@Nazwa_Konf, @Data, @Temat)
		)
		DECLARE @Godzina_Zakonczenia AS time
		SET @Godzina_Zakonczenia = (
			SELECT Godzina_Zakonczenia
			FROM Warsztaty 
			WHERE ID_Warsztatu = dbo.Pobierz_ID_Warsztatu(@Nazwa_Konf, @Data, @Temat)
		)
		DECLARE @Trwajace_Warsztaty AS int
		SET @Trwajace_Warsztaty = (
			SELECT COUNT(*)
			FROM Warsztaty
			WHERE ID_Warsztatu in (
				SELECT ID_Warsztatu
				FROM Warsztaty_Rezerwacje
				WHERE ID_Rezerwacji in (
					SELECT ID_Rezerwacji
					FROM Warsztaty_Rejestracje
					WHERE ID_Rejestracji = @ID_Rej AND Data_Anulowania IS NULL --w tym samym dniu konferencji dla danego uczestnika
				)
			) AND (@Godzina_Rozpoczecia BETWEEN Godzina_Rozpoczecia AND Godzina_Zakonczenia
				OR @Godzina_Zakonczenia BETWEEN Godzina_Rozpoczecia AND Godzina_Zakonczenia)
		)
		
		IF dbo.Rezerwacja_Warsztatu_Wolne_Miejsca(@ID_Rez_War) > 0 AND @Trwajace_Warsztaty = 0
		BEGIN
			INSERT INTO Warsztaty_Rejestracje
			(ID_Rejestracji, ID_Rezerwacji)
			VALUES (@ID_Rej, @ID_Rez_War)
		END
	END
GO

IF OBJECT_ID('Anuluj_Rejestracje_Warsztatu') IS NOT NULL
DROP PROC Anuluj_Rejestracje_Warsztatu
GO

IF OBJECT_ID('Anuluj_Rezerwacje_Warsztatu') IS NOT NULL
DROP PROC Anuluj_Rezerwacje_Warsztatu
GO

IF OBJECT_ID('Anuluj_Rejestracje_Dnia') IS NOT NULL
DROP PROC Anuluj_Rejestracje_Dnia
GO

IF OBJECT_ID('Anuluj_Rezerwacje_Dnia') IS NOT NULL
DROP PROC Anuluj_Rezerwacje_Dnia
GO

CREATE PROCEDURE Anuluj_Rejestracje_Warsztatu
	@Nazwa_Konf varchar(50),
	@Data date,
	@Temat varchar(50),
	@PESEL char(11)
	AS
	BEGIN
		SET NOCOUNT ON;
		DECLARE @NIP_Klienta AS char(10)
		SET @NIP_Klienta = (
			SELECT NIP_Klienta
			FROM Uczestnicy
			WHERE ID_Uczestnika = @PESEL
		)
		DECLARE @ID_Rez_War AS int
		SET @ID_Rez_War = (
			SELECT ID_Rezerwacji
			FROM Warsztaty_Rezerwacje 
			WHERE NIP_Klienta = @NIP_Klienta 
				AND ID_Warsztatu = dbo.Pobierz_ID_Warsztatu(@Nazwa_Konf, @Data, @Temat)
		)
		DECLARE @ID_Rej AS int 
		SET @ID_Rej = (
			SELECT ID_Rejestracji
			FROM Dni_Konferencji_Rejestracje
			WHERE ID_Uczestnika = @PESEL AND ID_Rezerwacji = (
				SELECT ID_Rezerwacji
				FROM Dni_Konferencji_Rezerwacje 
				WHERE NIP_Klienta = @NIP_Klienta 
					AND ID_Dnia_Konferencji = dbo.Pobierz_ID_Dnia(@Nazwa_Konf, @Data)
			)
		)
		UPDATE Warsztaty_Rejestracje
		SET Data_Anulowania = GETDATE()
		WHERE ID_Rejestracji = @ID_Rej AND ID_Rezerwacji = @ID_Rez_War
	END
GO

CREATE PROCEDURE Anuluj_Rezerwacje_Warsztatu
	@NIP_Klienta char(10),
	@Nazwa_Konf varchar(50),
	@Data date,
	@Temat varchar(50)
	AS
	BEGIN
		SET NOCOUNT ON;
		DECLARE @ID_Rez AS int
		SET @ID_Rez = (
			SELECT ID_Rezerwacji 
			FROM Warsztaty_Rezerwacje
			WHERE NIP_Klienta = @NIP_Klienta 
				AND ID_Warsztatu = dbo.Pobierz_ID_Warsztatu(@Nazwa_Konf, @Data, @Temat)
		)
		
		UPDATE Warsztaty_Rezerwacje
		SET Data_Anulowania = GETDATE()
		WHERE ID_Rezerwacji = @ID_Rez
	END
GO

CREATE PROCEDURE Anuluj_Rejestracje_Dnia
	@Nazwa_Konf varchar(50),
	@Data date,
	@PESEL char(11)
	AS
	BEGIN
	SET NOCOUNT ON;	
		DECLARE @ID_Rej AS int
		SET @ID_Rej = (
			SELECT ID_Rejestracji
			FROM Dni_Konferencji_Rejestracje
			WHERE ID_Rejestracji = (
				SELECT ID_Rezerwacji
				FROM Dni_Konferencji_Rezerwacje 
				WHERE ID_Dnia_Konferencji = dbo.Pobierz_ID_Dnia(@Nazwa_Konf, @Data) 
					AND NIP_Klienta = (
						SELECT NIP_Klienta
						FROM Uczestnicy
						WHERE ID_Uczestnika = @PESEL
				)
			)
		)
		UPDATE Dni_Konferencji_Rejestracje
		SET Data_Anulowania = GETDATE()
		WHERE ID_Rejestracji = @ID_Rej
	END
GO

CREATE PROCEDURE Anuluj_Rezerwacje_Dnia
	@NIP_Klienta char(10),
	@Nazwa_Konf varchar(50),
	@Data date
	AS
	BEGIN
	SET NOCOUNT ON;
		DECLARE @ID_Rez AS int
		SET @ID_Rez = (
			SELECT ID_Rezerwacji
			FROM Dni_Konferencji_Rezerwacje
			WHERE NIP_Klienta = @NIP_Klienta 
				AND ID_Dnia_Konferencji = dbo.Pobierz_ID_Dnia(@Nazwa_Konf, @Data)
		)
		UPDATE Dni_Konferencji_Rezerwacje
		SET Data_Anulowania = GETDATE()
		WHERE ID_Rezerwacji = @ID_Rez
	END
GO

IF OBJECT_ID('Warsztat_Zaplata') IS NOT NULL
DROP PROCEDURE Warsztat_Zaplata
GO
IF OBJECT_ID('Dzien_Konferencji_Zaplata') IS NOT NULL
DROP PROCEDURE Dzien_Konferencji_Zaplata
GO

CREATE PROCEDURE Warsztat_Zaplata
	@NIP_Klienta char(10),
	@Nazwa_Konf varchar(50),
	@Data date,
	@Temat varchar(50),
	@Kwota_Wplaty money
	AS
	BEGIN
		DECLARE @ID_Rez AS int
		SET @ID_Rez = (
			SELECT ID_Rezerwacji
			FROM Warsztaty_Rezerwacje
			WHERE ID_Warsztatu = dbo.Pobierz_ID_Warsztatu(@Nazwa_Konf, @Data, @Temat)
			AND NIP_Klienta = @NIP_Klienta
		)
		print @ID_Rez
		UPDATE Warsztaty_Rezerwacje
		SET Kwota_Zaplacona = Kwota_Zaplacona + @Kwota_Wplaty
		WHERE ID_Rezerwacji = @ID_Rez
	END
GO

CREATE PROCEDURE Dzien_Konferencji_Zaplata
	@NIP_Klienta char(10),
	@Nazwa_Konf varchar(50),
	@Data date,
	@Kwota_Wplaty money
	AS
	BEGIN
		DECLARE @ID_Rez AS int
		SET @ID_Rez = (
			SELECT ID_Rezerwacji
			FROM Dni_Konferencji_Rezerwacje
			WHERE ID_Dnia_Konferencji = dbo.Pobierz_ID_Dnia(@Nazwa_Konf, @Data)
			AND NIP_Klienta = @NIP_Klienta
		)
		
		UPDATE Dni_Konferencji_Rezerwacje
		SET Kwota_Zaplacona = Kwota_Zaplacona + @Kwota_Wplaty
		WHERE ID_Rezerwacji = @ID_Rez
	END
GO

IF OBJECT_ID('Anuluj_Nieoplacone_Rezerwacje') IS NOT NULL
DROP PROCEDURE Anuluj_Nieoplacone_Rezerwacje 
GO

CREATE PROCEDURE Anuluj_Nieoplacone_Rezerwacje
	AS
	BEGIN
		BEGIN TRANSACTION
			UPDATE Dni_Konferencji_Rezerwacje
			SET Data_Anulowania = GETDATE()
			WHERE ID_Rezerwacji in (
				SELECT ID_Rezerwacji
				FROM Dni_Konferencji_Rezerwacje
				WHERE ID_Dnia_Konferencji in (
					SELECT ID_Dnia_Konferencji
					FROM Dni_Konferencji
					WHERE DATEDIFF(WEEK, GETDATE(), Data) <= 1
				) AND Kwota_Zaplacona < Kwota_Do_Zaplaty
			)
			
			IF @@ERROR <> 0
			BEGIN
				RAISERROR('error', 16, 1)
				ROLLBACK TRANSACTION
			END
			
			UPDATE Warsztaty_Rezerwacje
			SET Data_Anulowania = GETDATE()
			WHERE ID_Rezerwacji in (
				SELECT ID_Rezerwacji
				FROM Warsztaty_Rezerwacje
				WHERE ID_Warsztatu in (
					SELECT ID_Warsztatu
					FROM Warsztaty
					WHERE DATEDIFF(WEEK, GETDATE(),
						 (SELECT Data
						  FROM Dni_Konferencji 
						  WHERE Dni_Konferencji.ID_Dnia_Konferencji = Warsztaty.ID_Dnia_Konferencji)
						 ) <= 1
				) AND Kwota_Zaplacona < Kwota_Do_Zaplaty
			)
			IF @@ERROR <> 0
			BEGIN
				RAISERROR('error', 16, 1)
				ROLLBACK TRANSACTION
			END
		COMMIT TRANSACTION
	END
GO