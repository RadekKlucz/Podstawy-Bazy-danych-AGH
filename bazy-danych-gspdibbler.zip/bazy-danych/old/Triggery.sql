IF OBJECT_ID('Anuluj_Rejestracje_Warsztatu_Trigger_Rez') IS NOT NULL
DROP TRIGGER Anuluj_Rejestracje_Warsztatu_Trigger_Rez
GO

IF OBJECT_ID('Anuluj_Rejestracje_Warsztatu_Trigger_Rej') IS NOT NULL
DROP TRIGGER Anuluj_Rejestracje_Warsztatu_Trigger_Rej
GO

IF OBJECT_ID('Anuluj_Rejestracje_Dnia_Trigger_Rez') IS NOT NULL
DROP TRIGGER Anuluj_Rejestracje_Dnia_Trigger_Rez
GO

CREATE TRIGGER Anuluj_Rejestracje_Warsztatu_Trigger_Rez
	ON Warsztaty_Rezerwacje
	FOR UPDATE
	AS
	BEGIN
		IF UPDATE(Data_Anulowania)
		BEGIN
			DECLARE @ID_Rez AS int
			SET @ID_Rez = (SELECT ID_Rezerwacji FROM INSERTED)
			
			UPDATE Warsztaty_Rejestracje
			SET Data_Anulowania = GETDATE()
			WHERE ID_Rezerwacji = @ID_Rez
		END
	END
GO

CREATE TRIGGER Anuluj_Rejestracje_Warsztatu_Trigger_Rej
	ON Dni_Konferencji_Rejestracje
	FOR UPDATE
	AS
	BEGIN
		IF UPDATE(Data_Anulowania)
		BEGIN
			DECLARE @ID_Rej AS int
			SET @ID_Rej = (SELECT ID_Rejestracji FROM INSERTED)
			
			UPDATE Warsztaty_Rejestracje
			SET Data_Anulowania = GETDATE()
			WHERE ID_Rejestracji = @ID_Rej
		END
	END
GO

CREATE TRIGGER Anuluj_Rejestracje_Dnia_Trigger_Rez
	ON Dni_Konferencji_Rezerwacje
	FOR UPDATE
	AS
	BEGIN
		IF UPDATE(Data_Anulowania)
		BEGIN
			DECLARE @ID_Rez AS int
			SET @ID_Rez = (SELECT ID_Rezerwacji FROM INSERTED)
			
			UPDATE Dni_Konferencji_Rejestracje
			SET Data_Anulowania = GETDATE()
			WHERE ID_Rezerwacji = @ID_Rez
		END	
	END
GO