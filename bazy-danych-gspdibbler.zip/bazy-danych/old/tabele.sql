IF OBJECT_ID('Warsztaty_Rejestracje', 'U') IS NOT NULL 
DROP TABLE Warsztaty_Rejestracje;
IF OBJECT_ID('Dni_Konferencji_Rejestracje', 'U') IS NOT NULL 
DROP TABLE Dni_Konferencji_Rejestracje;
IF OBJECT_ID('Uczestnicy', 'U') IS NOT NULL 
DROP TABLE Uczestnicy;
IF OBJECT_ID('Dni_Konferencji_Rezerwacje', 'U') IS NOT NULL 
DROP TABLE Dni_Konferencji_Rezerwacje;
IF OBJECT_ID('Warsztaty_Rezerwacje', 'U') IS NOT NULL 
DROP TABLE Warsztaty_Rezerwacje;
IF OBJECT_ID('Warsztaty', 'U') IS NOT NULL 
DROP TABLE Warsztaty;
IF OBJECT_ID('Dni_Konferencji', 'U') IS NOT NULL 
DROP TABLE Dni_Konferencji;
IF OBJECT_ID('Konferencje', 'U') IS NOT NULL 
DROP TABLE Konferencje;
IF OBJECT_ID('Klienci', 'U') IS NOT NULL 
DROP TABLE Klienci;

CREATE TABLE Konferencje (
  ID_Konferencji int IDENTITY(1, 1) NOT NULL,
  Nazwa varchar(50) UNIQUE NOT NULL,	--unique a nie pk ze wzgledu na oszczednosc miejsca
  Miasto varchar(50) NOT NULL,
  Ulica varchar(50) NOT NULL,
  Nr_Budynku int NOT NULL,
  Kod_Pocztowy char(6) NOT NULL,
  PRIMARY KEY(ID_Konferencji),
  CONSTRAINT Kod_Pocztowy_Konf CHECK (Kod_Pocztowy LIKE '[0-9][0-9]-[0-9][0-9][0-9]'), --sprawdzic mozliwosc zmiany na \d\d\d\d\d, ew. \d{2}-\d{3}
  CONSTRAINT Nr_Budynku_Konf CHECK (Nr_Budynku > 0)
)

CREATE TABLE Dni_Konferencji (
  ID_Dnia_Konferencji int IDENTITY(1, 1) NOT NULL,
  ID_Konferencji int FOREIGN KEY REFERENCES Konferencje(ID_Konferencji) NOT NULL,
  Data date NOT NULL,
  Cena_Bazowa money NOT NULL,
  Znizka_Studencka int NOT NULL,
  Liczba_Miejsc int NOT NULL,
  PRIMARY KEY(ID_Dnia_Konferencji),
  CONSTRAINT Wysokosc_Znizki_DK CHECK (Znizka_Studencka BETWEEN 0 AND 100),
  CONSTRAINT Liczba_Miejsc_DK CHECK (Liczba_Miejsc > 0)
)

CREATE TABLE Warsztaty (
  ID_Warsztatu int IDENTITY(1, 1) NOT NULL,
  ID_Dnia_Konferencji int FOREIGN KEY REFERENCES Dni_Konferencji(ID_Dnia_Konferencji) NOT NULL,
  Temat varchar(50) NOT NULL,
  Cena money NOT NULL,
  Liczba_miejsc int NOT NULL,
  Godzina_Rozpoczecia time NOT NULL,
  Godzina_Zakonczenia time NOT NULL,
  PRIMARY KEY(ID_Warsztatu),
  CONSTRAINT Liczba_Miejsc_War CHECK (Liczba_Miejsc > 0)
)

CREATE TABLE Klienci (
  Nazwa varchar(50)	UNIQUE NOT NULL,
  NIP char(10) NOT NULL,
  Nr_Konta varchar(50),
  Nr_Telefonu varchar(15) NOT NULL,
  Email varchar(50),
  Miasto varchar(50) NOT NULL,
  Ulica varchar(50) NOT NULL,
  Nr_Budynku int NOT NULL,
  Nr_Lokalu int,
  Kod_Pocztowy 	varchar(50) NOT NULL,
  PRIMARY KEY(NIP),
  CONSTRAINT Sprawdz_Email_Kl CHECK (Email LIKE '%_@_%._%'),
  CONSTRAINT Sprawdz_NIP_Kl CHECK (NIP LIKE '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]'),
  CONSTRAINT Kod_Pocztowy_Kl CHECK (Kod_pocztowy LIKE '[0-9][0-9]-[0-9][0-9][0-9]'), 
  CONSTRAINT Nr_Budynku_Kl CHECK (Nr_Budynku > 0),
  CONSTRAINT Nr_Lokalu_Kl CHECK (Nr_Lokalu > 0 OR Nr_Lokalu IS NULL)
)

CREATE TABLE Uczestnicy (
  ID_Uczestnika char(11) not null,
  NIP_Klienta char(10) FOREIGN KEY REFERENCES Klienci(NIP) NOT NULL,
  Imie varchar(50) NOT NULL,	
  Nazwisko varchar(50) NOT NULL,
  Nr_Legitymacji int,
  PRIMARY KEY(ID_Uczestnika),
  CONSTRAINT Nr_Legitymacji_Ucz CHECK (Nr_Legitymacji LIKE '[0-9][0-9][0-9][0-9][0-9][0-9]'),
  CONSTRAINT ID_Ucz_PESEL CHECK (ID_Uczestnika LIKE '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]')
)

CREATE TABLE Warsztaty_Rezerwacje (
  ID_Rezerwacji int IDENTITY(1, 1) NOT NULL,
  ID_Warsztatu int FOREIGN KEY REFERENCES Warsztaty(ID_Warsztatu) NOT NULL,
  NIP_Klienta char(10) FOREIGN KEY REFERENCES Klienci(NIP) NOT NULL,
  Liczba_Miejsc int NOT NULL,
  Data_Rezerwacji date DEFAULT GETDATE() NOT NULL,
  Data_Anulowania date,
  Kwota_Do_Zaplaty money DEFAULT 0 NOT NULL,
  Kwota_Zaplacona money DEFAULT 0 NOT NULL,
  PRIMARY KEY(ID_Rezerwacji),
  CONSTRAINT Liczba_Miejsc_WR CHECK (Liczba_Miejsc > 0)
)

CREATE TABLE Dni_Konferencji_Rezerwacje (
  ID_Rezerwacji int IDENTITY(1, 1) NOT NULL,
  ID_Dnia_Konferencji int FOREIGN KEY REFERENCES Dni_Konferencji(ID_Dnia_Konferencji) NOT NULL,
  NIP_Klienta char(10) FOREIGN KEY REFERENCES Klienci(NIP) NOT NULL,
  Liczba_Miejsc int NOT NULL,
  Data_Rezerwacji date DEFAULT GETDATE() NOT NULL,
  Data_Anulowania date,
  Kwota_Do_Zaplaty money DEFAULT 0 NOT NULL,
  Kwota_Zaplacona money DEFAULT 0 NOT NULL,
  PRIMARY KEY(ID_Rezerwacji),
  CONSTRAINT Liczba_Miejsc_DKR CHECK (Liczba_Miejsc > 0)
)

CREATE TABLE Dni_Konferencji_Rejestracje (
  ID_Rejestracji int IDENTITY(1, 1) NOT NULL,
  ID_Rezerwacji int FOREIGN KEY REFERENCES Dni_Konferencji_Rezerwacje(ID_Rezerwacji) NOT NULL,
  ID_Uczestnika char(11) FOREIGN KEY REFERENCES Uczestnicy(ID_Uczestnika) NOT NULL,
  Data_Rejestracji date DEFAULT GETDATE() NOT NULL,
  Data_Anulowania date,
  PRIMARY KEY(ID_Rejestracji),
)

CREATE TABLE Warsztaty_Rejestracje (
  ID_Rezerwacji int FOREIGN KEY REFERENCES Warsztaty_Rezerwacje(ID_Rezerwacji) NOT NULL,
  ID_Rejestracji int FOREIGN KEY REFERENCES Dni_Konferencji_Rejestracje(ID_Rejestracji) NOT NULL,
  Data_Rejestracji date DEFAULT GETDATE() NOT NULL,
  Data_Anulowania date,
)