IF OBJECT_ID('Nadchodzace_Konferencje') IS NOT NULL
DROP VIEW Nadchodzace_Konferencje
GO

CREATE VIEW Nadchodzace_Konferencje
	AS
	SELECT Nazwa, Miasto, Ulica, Nr_Budynku, Kod_Pocztowy, MIN(Data) as Dzien_Rozpoczecia, MAX(Data) as Dzien_Zakonczenia
	FROM Konferencje join Dni_Konferencji
	ON Konferencje.ID_Konferencji = Dni_Konferencji.ID_Konferencji
	GROUP BY Nazwa, Miasto, Ulica, Nr_Budynku, Kod_Pocztowy
	HAVING MIN(Data) > GETDATE()
GO

IF OBJECT_ID('Nadchodzace_Warsztaty') IS NOT NULL
DROP VIEW Nadchodzace_Warsztaty
GO

CREATE VIEW Nadchodzace_Warsztaty
	AS
	SELECT Konferencje.Nazwa, Temat, Cena,
	Warsztaty.Liczba_miejsc, Warsztaty.Liczba_miejsc - (
		SELECT SUM(Warsztaty_Rezerwacje.Liczba_Miejsc) 
		FROM Warsztaty_Rezerwacje 
		WHERE Warsztaty_Rezerwacje.ID_Warsztatu = Warsztaty.ID_Warsztatu
		AND Data_Anulowania IS NULL) as Liczba_Miejsc_Wolnych,
	Godzina_Rozpoczecia, Godzina_Zakonczenia
	FROM Warsztaty 
	join Dni_Konferencji
	ON Warsztaty.ID_Dnia_Konferencji = Dni_Konferencji.ID_Dnia_Konferencji
	join Konferencje
	ON Konferencje.ID_Konferencji = Dni_Konferencji.ID_Konferencji
	WHERE Dni_Konferencji.Data > GETDATE()
GO

IF OBJECT_ID('Klienci_Nadchodzacych_Konferencji') IS NOT NULL
DROP VIEW Klienci_Nadchodzacych_Konferencji
GO

CREATE VIEW Klienci_Nadchodzacych_Konferencji
	AS
	SELECT Konferencje.Nazwa AS Nazwa_Konferencji, Klienci.Nazwa AS Nazwa_Klienta, 
	SUM(Dni_Konferencji_Rezerwacje.Liczba_Miejsc) AS Liczba_Miejsc
	FROM Konferencje join Dni_Konferencji 
	ON Konferencje.ID_Konferencji = Dni_Konferencji.ID_Konferencji
	join Dni_Konferencji_Rezerwacje
	ON Dni_Konferencji_Rezerwacje.ID_Dnia_Konferencji = Dni_Konferencji.ID_Dnia_Konferencji
	join Klienci
	ON Klienci.NIP = Dni_Konferencji_Rezerwacje.NIP_Klienta
	WHERE Dni_Konferencji.Data > GETDATE()
	AND Dni_Konferencji_Rezerwacje.Data_Anulowania IS NULL
	GROUP BY Konferencje.Nazwa, Klienci.Nazwa
GO

IF OBJECT_ID('Uczestnicy_Nadchodzacych_Konferencji') IS NOT NULL
DROP VIEW Uczestnicy_Nadchodzacych_Konferencji
GO

CREATE VIEW Uczestnicy_Nadchodzacych_Konferencji
	AS
	SELECT Uczestnicy.ID_Uczestnika, Uczestnicy.Imie, Uczestnicy.Nazwisko, Konferencje.Nazwa
	FROM Dni_Konferencji_Rejestracje join Uczestnicy
	ON Dni_Konferencji_Rejestracje.ID_Uczestnika = Uczestnicy.ID_Uczestnika
	join Dni_Konferencji_Rezerwacje
	ON Dni_Konferencji_Rezerwacje.ID_Rezerwacji = Dni_Konferencji_Rejestracje.ID_Rezerwacji
	join Dni_Konferencji
	ON Dni_Konferencji.ID_Dnia_Konferencji = Dni_Konferencji_Rezerwacje.ID_Dnia_Konferencji
	join Konferencje
	ON Konferencje.ID_Konferencji = Dni_Konferencji.ID_Konferencji
	WHERE Dni_Konferencji_Rejestracje.Data_Anulowania IS NULL
GO

IF OBJECT_ID('Uczestnicy_Nadchodzacych_Warsztatow') IS NOT NULL
DROP VIEW Uczestnicy_Nadchodzacych_Warsztatow
GO

CREATE VIEW Uczestnicy_Nadchodzacych_Warsztatow
	AS
	SELECT Warsztaty.Temat, Uczestnicy.Imie, Uczestnicy.Nazwisko, Uczestnicy.ID_Uczestnika
	FROM Warsztaty_Rejestracje join Dni_Konferencji_Rejestracje
	ON Warsztaty_Rejestracje.ID_Rejestracji = Dni_Konferencji_Rejestracje.ID_Rejestracji
	join Uczestnicy
	ON Uczestnicy.ID_Uczestnika = Dni_Konferencji_Rejestracje.ID_Uczestnika
	join Warsztaty_Rezerwacje
	ON Warsztaty_Rejestracje.ID_Rezerwacji = Warsztaty_Rezerwacje.ID_Rezerwacji
	join Warsztaty
	ON Warsztaty.ID_Warsztatu = Warsztaty_Rezerwacje.ID_Warsztatu	
	WHERE Warsztaty_Rejestracje.Data_Anulowania IS NULL
GO

IF OBJECT_ID('Nieoplacone_Rezerwacje_Dni') IS NOT NULL
DROP VIEW Nieoplacone_Rezerwacje_Dni
GO

CREATE VIEW Nieoplacone_Rezerwacje_Dni
	AS
	SELECT Konferencje.Nazwa as Nazwa_Konferencji, Dni_Konferencji.Data,
	Klienci.Nazwa as Nazwa_Klienta, Kwota_Do_Zaplaty, Kwota_Zaplacona, 
	Kwota_Do_Zaplaty - Kwota_Zaplacona as Roznica, Dni_Konferencji_Rezerwacje.Liczba_Miejsc, 
	Klienci.Nr_Telefonu, Klienci.Email
	FROM Dni_Konferencji_Rezerwacje 
	join Dni_Konferencji
	ON Dni_Konferencji.ID_Dnia_Konferencji = Dni_Konferencji_Rezerwacje.ID_Dnia_Konferencji
	join Konferencje
	ON Konferencje.ID_Konferencji = Dni_Konferencji.ID_Konferencji
	join Klienci
	ON Klienci.NIP = Dni_Konferencji_Rezerwacje.NIP_Klienta
	WHERE Kwota_Do_Zaplaty < Kwota_Zaplacona
	AND Dni_Konferencji.Data > GETDATE()
	AND Dni_Konferencji_Rezerwacje.Data_Anulowania IS NULL
GO

IF OBJECT_ID('Nieoplacone_Rezerwacje_Warsztatow') IS NOT NULL
DROP VIEW Nieoplacone_Rezerwacje_Warsztatow
GO

CREATE VIEW Nieoplacone_Rezerwacje_Warsztatow
	AS
	SELECT Warsztaty.Temat, Klienci.Nazwa, Kwota_Do_Zaplaty, Kwota_Zaplacona,
	 Kwota_Do_Zaplaty - Kwota_Zaplacona as Roznica, Warsztaty_Rezerwacje.Liczba_Miejsc
	FROM Warsztaty_Rezerwacje
	join Warsztaty
	ON Warsztaty.ID_Warsztatu = Warsztaty_Rezerwacje.ID_Warsztatu
	join Klienci
	ON Klienci.NIP = Warsztaty_Rezerwacje.NIP_Klienta
	join Dni_Konferencji
	ON Dni_Konferencji.ID_Dnia_Konferencji = Warsztaty.ID_Dnia_Konferencji
	WHERE Kwota_Do_Zaplaty < Kwota_Zaplacona
	AND Warsztaty_Rezerwacje.Data_Anulowania IS NULL
	AND Dni_Konferencji.Data > GETDATE()
GO

IF OBJECT_ID('Niewykorzystane_Rezerwacje_Dni') IS NOT NULL
DROP VIEW Niewykorzystane_Rezerwacje_Dni
GO

CREATE VIEW Niewykorzystane_Rezerwacje_Dni
	AS
	SELECT Konferencje.Nazwa as Nazwa_Konferencji, Dni_Konferencji.Data, Klienci.Nazwa as Nazwa_Klienta,
	Dni_Konferencji_Rezerwacje.Liczba_Miejsc, COUNT(Dni_Konferencji_Rejestracje.ID_Rejestracji) as Liczba_Miejsc_Wykorzystanych
	FROM Dni_Konferencji_Rezerwacje
	join Dni_Konferencji
	ON Dni_Konferencji.ID_Dnia_Konferencji = Dni_Konferencji_Rezerwacje.ID_Dnia_Konferencji
	join Dni_Konferencji_Rejestracje
	ON Dni_Konferencji_Rejestracje.ID_Rezerwacji = Dni_Konferencji_Rezerwacje.ID_Rezerwacji
	join Klienci
	ON Klienci.NIP = Dni_Konferencji_Rezerwacje.NIP_Klienta
	join Konferencje
	ON Dni_Konferencji.ID_Konferencji = Konferencje.ID_Konferencji
	WHERE Dni_Konferencji_Rezerwacje.Data_Anulowania IS NULL
	AND Dni_Konferencji.Data > GETDATE()
	GROUP BY Konferencje.Nazwa, Dni_Konferencji.Data, Klienci.Nazwa, Dni_Konferencji_Rezerwacje.Liczba_Miejsc
GO

IF OBJECT_ID('Niewykorzystane_Rezerwacje_Warsztatow') IS NOT NULL
DROP VIEW Niewykorzystane_Rezerwacje_Warsztatow
GO

CREATE VIEW Niewykorzystane_Rezerwacje_Warsztatow
	AS
	SELECT Klienci.Nazwa, Warsztaty.Temat, Warsztaty_Rezerwacje.Liczba_Miejsc,
	COUNT(Warsztaty_Rejestracje.ID_Rejestracji) as Liczba_Miejsc_Wykorzystanych 
	FROM Warsztaty_Rezerwacje
	join Warsztaty_Rejestracje
	ON Warsztaty_Rezerwacje.ID_Rezerwacji = Warsztaty_Rejestracje.ID_Rezerwacji
	join Klienci
	ON Klienci.NIP = Warsztaty_Rezerwacje.NIP_Klienta
	join Warsztaty
	ON Warsztaty.ID_Warsztatu = Warsztaty_Rezerwacje.ID_Warsztatu
	join Dni_Konferencji
	ON Dni_Konferencji.ID_Dnia_Konferencji = Warsztaty.ID_Dnia_Konferencji
	WHERE Warsztaty_Rezerwacje.Data_Anulowania IS NULL 
	AND Dni_Konferencji.Data > GETDATE()
	GROUP BY Klienci.Nazwa, Warsztaty.Temat, Warsztaty_Rezerwacje.Liczba_Miejsc
GO

IF OBJECT_ID('Klienci_Aktywnosc') IS NOT NULL
DROP VIEW Klienci_Aktywnosc
GO

CREATE VIEW Klienci_Aktywnosc
	AS
	SELECT Klienci.Nazwa, SUM(Dni_Konferencji_Rezerwacje.Liczba_Miejsc) as Rez_Dni_Konferencji,
	SUM(Warsztaty_Rezerwacje.Liczba_Miejsc) as Rez_Warsztatow, 
	SUM(Dni_Konferencji_Rezerwacje.Kwota_Zaplacona) + SUM(Warsztaty_Rezerwacje.Kwota_Zaplacona) as Suma_Wplat
	FROM Klienci
	join Dni_Konferencji_Rezerwacje
	ON Dni_Konferencji_Rezerwacje.NIP_Klienta = Klienci.NIP
	join Warsztaty_Rezerwacje
	ON Warsztaty_Rezerwacje.NIP_Klienta = Klienci.NIP
	WHERE Dni_Konferencji_Rezerwacje.Data_Anulowania IS NULL 
	AND Warsztaty_Rezerwacje.Data_Anulowania IS NULL
	GROUP BY Klienci.Nazwa
GO