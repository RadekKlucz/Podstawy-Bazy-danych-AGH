IF OBJECT_ID('Dzien_Konferencji_Wolne_Miejsca') IS NOT NULL
DROP FUNCTION Dzien_Konferencji_Wolne_Miejsca
GO
IF OBJECT_ID('Warsztat_Wolne_Miejsca') IS NOT NULL
DROP FUNCTION Warsztat_Wolne_Miejsca
GO
IF OBJECT_ID('Rezerwacja_Dnia_Wolne_Miejsca') IS NOT NULL
DROP FUNCTION Rezerwacja_Dnia_Wolne_Miejsca
GO
IF OBJECT_ID('Rezerwacja_Warsztatu_Wolne_Miejsca') IS NOT NULL
DROP FUNCTION Rezerwacja_Warsztatu_Wolne_Miejsca
GO

CREATE FUNCTION Dzien_Konferencji_Wolne_Miejsca(@ID_Dnia int)
	RETURNS int
	AS
	BEGIN
		DECLARE @Miejsca AS int
		SET @Miejsca = (
			SELECT Liczba_Miejsc
			FROM Dni_Konferencji
			WHERE ID_Dnia_Konferencji = @ID_Dnia
		)
		DECLARE @Zajete AS int
		SET @Zajete = (
			SELECT SUM(Liczba_Miejsc)
			FROM Dni_Konferencji_Rezerwacje
			WHERE ID_Dnia_Konferencji = @ID_Dnia AND Data_Anulowania IS NULL
		)
		IF @Zajete IS NULL
		BEGIN
			SET @Zajete = 0
		END
		RETURN (@Miejsca - @Zajete)
	END
GO

CREATE FUNCTION Warsztat_Wolne_Miejsca(@ID_Warsztatu int)
	RETURNS int
	AS
	BEGIN
		DECLARE @Miejsca AS int
		SET @Miejsca = (
			SELECT Liczba_Miejsc
			FROM Warsztaty
			WHERE ID_Warsztatu = @ID_Warsztatu
		)
		DECLARE @Zajete AS int
		SET @Zajete = (
			SELECT SUM(Liczba_Miejsc)
			FROM Warsztaty_Rezerwacje
			WHERE ID_Warsztatu = @ID_Warsztatu AND Data_Anulowania IS NULL
		)
		IF @Zajete IS NULL
		BEGIN
			SET @Zajete = 0
		END
		RETURN (@Miejsca - @Zajete)
	END
GO
CREATE FUNCTION Rezerwacja_Dnia_Wolne_Miejsca(@ID_Rezerwacji int)
	RETURNS int
	AS
	BEGIN
		DECLARE @Miejsca AS int
		SET @Miejsca = (
			SELECT Liczba_Miejsc
			FROM Dni_Konferencji_Rezerwacje
			WHERE ID_Rezerwacji = @ID_Rezerwacji
		)
		DECLARE @Zajete AS int
		SET @Zajete = (
			SELECT COUNT(*)
			FROM Dni_Konferencji_Rejestracje
			WHERE ID_Rezerwacji = @ID_Rezerwacji AND Data_Anulowania IS NULL
		)
		IF @Zajete IS NULL
		BEGIN
			SET @Zajete = 0
		END
		RETURN (@Miejsca - @Zajete)
	END
GO

CREATE FUNCTION Rezerwacja_Warsztatu_Wolne_Miejsca(@ID_Rezerwacji int)
	RETURNS int
	AS
	BEGIN
		DECLARE @Miejsca AS int
		SET @Miejsca = (
			SELECT Liczba_Miejsc
			FROM Warsztaty_Rezerwacje
			WHERE ID_Rezerwacji = @ID_Rezerwacji
		)
		DECLARE @Zajete AS int
		SET @Zajete = (
			SELECT COUNT(*)
			FROM Warsztaty_Rejestracje
			WHERE ID_Rezerwacji = @ID_Rezerwacji AND Data_Anulowania IS NULL
		)
		IF @Zajete IS NULL
		BEGIN
			SET @Zajete = 0
		END
		RETURN (@Miejsca - @Zajete)
	END
GO


--funkcje pomocnicze
IF OBJECT_ID('Pobierz_ID_Dnia') IS NOT NULL
DROP FUNCTION Pobierz_ID_Dnia
GO
IF OBJECT_ID('Pobierz_ID_Warsztatu') IS NOT NULL
DROP FUNCTION Pobierz_ID_Warsztatu
GO

CREATE FUNCTION Pobierz_ID_Dnia(@Nazwa_Konf varchar(50), @Data date)
	RETURNS int
	AS
	BEGIN
		DECLARE @ID_Dnia AS int
		SET @ID_Dnia = ( 
			SELECT ID_Dnia_Konferencji
			FROM Dni_Konferencji
			WHERE Data = @Data AND ID_Konferencji = (
				SELECT ID_Konferencji
				FROM Konferencje
				WHERE Nazwa = @Nazwa_Konf
			)
		)
		RETURN @ID_Dnia
	END
GO

CREATE FUNCTION Pobierz_ID_Warsztatu(@Nazwa_Konf varchar(50), @Data date, @Temat varchar(50))
	RETURNS int
	AS
	BEGIN
		DECLARE @ID_Warsztatu AS int
		SET @ID_Warsztatu = (
			SELECT ID_Warsztatu
			FROM Warsztaty
			WHERE Temat = @Temat AND ID_Dnia_Konferencji = (
				SELECT ID_Dnia_Konferencji
				FROM Dni_Konferencji
				WHERE Data = @Data AND ID_Konferencji = (
					SELECT ID_Konferencji
					FROM Konferencje
					WHERE Nazwa = @Nazwa_Konf
				)				
			)
		)
		RETURN @ID_Warsztatu
	END
GO