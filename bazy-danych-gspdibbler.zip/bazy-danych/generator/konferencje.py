#-*- coding: utf-8

from random import randint
from generator import Generator

class Konferencja(object):
    ID = 1
    
    def __init__(self, Nazwa, Miasto, Ulica):
        self.ID_Konf = Konferencja.ID
        Konferencja.ID = Konferencja.ID + 1
        self.Nazwa = Nazwa
        self.Miasto = Miasto
        self.Ulica = Ulica
        self.Nr_Budynku = randint(1, 200)
        self.Kod_Pocztowy = str(randint(10, 99)) + '-' + str(randint(100, 999))
        self.lista_dni = []
        
    def __str__(self):
        return 'exec Dodaj_Konferencje \'' + self.Nazwa + '\', \'' + self.Miasto + '\', \'' \
         + self.Ulica + '\', ' + str(self.Nr_Budynku) + ', \'' + self.Kod_Pocztowy + '\'\n'

class Dzien_Konferencji(object):
    ID = 1
    
    def __init__(self, Nazwa, Data):
        self.ID_DK = Dzien_Konferencji.ID
        Dzien_Konferencji.ID = Dzien_Konferencji.ID + 1
        self.Nazwa = Nazwa
        self.Data = Data
        self.Cena = randint(10, 30) * 10
        self.Znizka = randint(0, 20)
        self.Miejsca = randint(5, 20) * 10
        
    def __str__(self):
        return 'exec Dodaj_Dzien_Konferencji \'' + self.Nazwa + '\', \'' + self.Data + '\', ' \
         + str(self.Cena) + ', ' + str(self.Znizka) + ', ' + str(self.Miejsca) + '\n'


class Warsztat(object):
    ID = 1
    
    def __init__(self, Nazwa, Data, Temat):
        self.Nazwa = Nazwa
        self.Data = Data
        self.Temat = Temat
        self.Cena = randint(10, 20) * 10
        self.Miejsca = randint(5, 9) * 5
        h = randint(8, 20)
        self.godz_rozp = str(h) + ':' + str(randint(0, 11) * 5)
        self.godz_zak = str(h+randint(1, 2)) + ':' + str(randint(0, 11) * 5)

    def __str__(self):
        return 'exec Dodaj_Warsztat \'' + self.Nazwa + '\', \'' + self.Data + '\', \'' + self.Temat + \
        '\', ' + str(self.Cena) + ', ' + str(self.Miejsca) + ', \'' + self.godz_rozp + '\', \'' + self.godz_zak + '\'\n'
         
class Generator_Konferencji(Generator):
    
    def __init__(self, nazwy, miasta, ulice):
        self.nazwy = self.open_and_parse(nazwy)
        self.miasta = self.open_and_parse(miasta)
        self.ulice = self.open_and_parse(ulice)
        self.lista_konf = []
        
    def generuj(self, liczba_konf=10):
        for i in xrange(liczba_konf):
            nazwy_kw = self.nazwy[i].split(',')
            nazwa = nazwy_kw[0]
            nazwy_war = nazwy_kw[1:-1]
            konf = Konferencja(nazwa, self.pick(self.miasta), self.pick(self.ulice))
            lista_dni = []
            data1 = '2014-' + str(randint(1, 12)) + '-'
            dzien1 = randint(1, 25)
            
            for j in xrange(randint(2, 4)):
                dzien = Dzien_Konferencji(nazwa, data1 + str(dzien1+j))
                warsztaty = []
                for k in xrange(randint(1, 2)):
                    warsztat = Warsztat(nazwa, data1 + str(dzien1+j), nazwy_war[k])
                    warsztaty.append(warsztat)
                dzien.warsztaty = warsztaty
                lista_dni.append(dzien)
            konf.lista_dni = lista_dni
            self.lista_konf.append(konf)
            
            
            
            
            
            
