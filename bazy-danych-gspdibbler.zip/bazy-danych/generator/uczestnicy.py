#-*- coding: utf-8

from random import randint
from generator import Generator

class Uczestnik(object):    
    def __init__(self, Imie, Nazwisko, NIP):
        self.Imie = Imie
        self.Nazwisko = Nazwisko
        self.ID = self.gen_pesel()
        self.NIP = NIP
        self.Nr_Leg = None if randint(0, 4) != 1 else str(randint(100000, 999999))
    
    def gen_pesel(self):
        pesel = str(randint(50, 90)) + str(randint(10, 21)-9) + \
            str(randint(1, 30)) + str(randint(10000, 99999))
        return pesel
    
    def __str__(self):
        return 'exec Dodaj_Uczestnika ' + self.NIP + ', ' + self.ID + ', ' + \
            self.Imie + ', ' + self.Nazwisko + ( '' if self.Nr_Leg is None else ', ' + self.Nr_Leg) + '\n'
        
class Generator_Uczestnikow(Generator):
    def __init__(self, imiona, nazwiska, NIP):
        self.imiona = self.open_and_parse(imiona)
        self.nazwiska = self.open_and_parse(nazwiska)
        self.lista_ucz = []
        self.NIP = NIP

    def generuj(self, liczba_uczestnikow=10):
        for i in xrange(liczba_uczestnikow):
            self.lista_ucz.append(Uczestnik(self.pick(self.imiona), \
            self.pick(self.nazwiska), self.NIP))
            
