#-*- coding: utf-8

from random import randint

class Generator(object):
    def open_and_parse(self, plik):
        dane = open(plik)
        a = [ line[0:-2] for line in dane]
        dane.close()
        return a
    
    def pick(self, lista):
        return lista[randint(0, len(lista)-1)]
