#-*- coding: utf-8

from random import randint
from generator import Generator

class Klient(object):
    ID = 1
    
    def __init__(self, Nazwa, Miasto, Ulica):
        self.ID_Klienta = Klient.ID
        Klient.ID = Klient.ID + 1
        self.Nazwa = Nazwa
        self.NIP = ''.join([str(randint(0, 9)) for i in xrange(10) ])
        self.Nr_Konta = ''.join([str(randint(0, 9)) for i in xrange(20) ])
        self.Nr_Telefonu = ''.join([str(randint(0, 9)) for i in xrange(10) ])
        self.Email = self.gen_email(Nazwa)
        self.Miasto = Miasto
        self.Ulica = Ulica
        self.Nr_Budynku = randint(1, 200)
        self.Nr_Lokalu = randint(1, 20)
        self.Kod_Pocztowy = str(randint(10, 99)) + '-' + str(randint(100, 999))
    
    def __str__(self):
        return 'exec Dodaj_Klienta ' + self.Nazwa + ', ' + self.NIP + ', ' + self.Nr_Telefonu + ', ' \
        + self.Miasto + ', ' + self.Ulica + ', ' + self.Kod_Pocztowy + ', ' + str(self.Nr_Budynku) \
        + ', ' + str(self.Nr_Lokalu) + ', ' + self.Nr_Konta + ', ' + self.Email + '\n'
    
    def gen_email(self, nazwa):
        a = ['onet', 'interia', 'wp']
        b = ['pl', 'eu', 'com', 'net']
        c = str(randint(1, 999))
        nazwa = nazwa.replace(' ', '').replace('ó', 'o').replace('ł', 'l')
        nazwa = nazwa[0:8] if len(nazwa) > 10 else nazwa
        nazwa = nazwa.lower()
        return nazwa + c + '@' + a[randint(0, 2)] + '.' + b[randint(0, 3)]


class Generator_Klientow(Generator):
    
    def __init__(self, firmy, imiona, nazwiska, miasta, ulice):
        self.firmy = self.open_and_parse(firmy)
        self.imiona = self.open_and_parse(imiona)
        self.nazwiska = self.open_and_parse(nazwiska)
        self.miasta = self.open_and_parse(miasta)
        self.ulice = self.open_and_parse(ulice)
        self.lista_kl = []
        
    def generuj(self, liczba_firm=10, liczba_osob=10):
        for i in xrange(liczba_firm):
            self.lista_kl.append(Klient(self.pick(self.firmy), \
            self.pick(self.miasta), self.pick(self.ulice)))

        for i in xrange(liczba_osob):
            self.lista_kl.append( 
            Klient( self.pick(self.imiona) + ' ' + self.pick(self.nazwiska),\
            self.pick(self.miasta), self.pick(self.ulice) ) )
                
    
    
    
    
