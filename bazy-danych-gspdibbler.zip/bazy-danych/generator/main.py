#-*- coding: utf-8
from random import randint

from klienci import Generator_Klientow, Klient
from uczestnicy import Generator_Uczestnikow, Uczestnik
from konferencje import Generator_Konferencji, Konferencja, Dzien_Konferencji, Warsztat
        

#GENEROWANIE KLIENTOW + UCZESTNIKOW
gen_kl = Generator_Klientow("dane/firmy.txt", "dane/imiona.txt", \
"dane/nazwiska.txt", "dane/miasta.txt", "dane/ulice.txt")

gen_kl.generuj()
klienci = gen_kl.lista_kl 

for kl in klienci:
    gen = Generator_Uczestnikow("dane/imiona.txt", "dane/nazwiska.txt", kl.NIP)
    gen.generuj()
    kl.lista_ucz = gen.lista_ucz
#KONIEC KLIENTOW + UCZESTNIKOW

#GENEROWANIE KONF, DNI, WARSZTATOW
gen_konf = Generator_Konferencji("dane/nazwy.txt", "dane/miasta.txt", "dane/ulice.txt")

gen_konf.generuj(3)
konferencje = gen_konf.lista_konf

for k in konferencje:
    print k
    for j in k.lista_dni:
        print j
        for m in j.warsztaty:
            print m
#KONIEC 
