### Channel name: 5-ktorą-z-poniższych-cech
___

Harry: 





![Screenshot_2021-02-04_at_10.06.08.png](806812881545854976_Screenshot_2021-02-04_at_10.06.08.png?raw=true)

Reactions:  🅱️ - 7 

___
Oliver: 

B?

___
Sophie: 

Superkluczem relacji r o schemacie R = {A1, A2,..., An} nazywamy dowolny zbiór atrybutów K z R
taki, że zachodzi zależność funkcyjna K -> R
- inaczej mówiąc, wartość każdego atrybutu ma być jednoznacznie zdeterminowana przez wartości
atrybutów zbioru K. Jednym z nadkluczy(superkluczy) jest zawsze trywialny zbiór wszystkich
atrybutów R.

___
Jacob: 





![unknown.png](806816823609524224_unknown.png?raw=true)

___