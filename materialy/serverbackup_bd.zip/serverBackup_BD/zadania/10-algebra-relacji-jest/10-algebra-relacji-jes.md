### Channel name: 10-algebra-relacji-jest
___

Mason: 





![unknown.png](806813473899282452_unknown.png?raw=true)

Reactions:  🇨 - 3 

___
Myles: 





![unknown.png](806813737347579934_unknown.png?raw=true)

___
Jacob: 

tu jesteście pewni C?

___
Lauren: 

tez sie zastanawiam

___
Cooper: 

tak bym powiedziała

___
Jacob: 

w sumie racja, reszta raczej nie pasuje

___
Kyle: 

jest językiem czystym, służącym do udowodnienia właściwości dot. mocy obliczeniowej i optymalizacji, może D? ale raczej C

___
Jacob: 

do udowadniania, a nie do wyliczania złożoności

___
Kyle: 

racja, to na pewno C

___
Jacob: 





![unknown.png](806817151695454268_unknown.png?raw=true)

___