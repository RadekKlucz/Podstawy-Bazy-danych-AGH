### Channel name: 6-wskaz-prawdziwe-twierdzenie
___

Harry: 





![Screenshot_2021-02-04_at_10.00.55.png](806811600623239169_Screenshot_2021-02-04_at_10.00.55.png?raw=true)

Reactions:  🇩 - 6 

___
Jacob: 

na pewno nie B @Harry

Reactions:  👍 - 1 

___
Subaru Natsuki: 

D chyba

___
Lily: 





![unknown.png](806813787096481802_unknown.png?raw=true)

___
Lily: 

Opracowanie na wiki mówi, że chyba nie D

___
Haroldzina: 

powinny, nie muszą

Reactions:  👍 - 1 

___
Emily: 

wciąż D

___
Haroldzina: 

c jest źle

___
Sophie: 

ok

___
Sophie: 

Usunę, żeby ludzi nie myliło

___
Cooper: 

"While a primary key may exist on its own, a foreign key must always reference to a primary key somewhere."

___
Sophie: 





![pbd.png](806815352742346793_pbd.png?raw=true)

___
Sophie: 

Nie C, bo nie muszą mieć takiej samej nazwy

___
Sophie: 

Nie A, bo mogą się powtarzać

___
Oliver: 

To bedzie d

___
Oliver: 

bo wtedy łaczymy do samej siebie i powinnien to byc klucz glowny

___
Jacob: 





![unknown.png](806817088604995604_unknown.png?raw=true)

___