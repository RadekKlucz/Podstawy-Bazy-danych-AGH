### Channel name: 2-wskaż-które-ograniczenia-można
___

Hermione: 





![Zrzut_ekranu_2021-02-4_o_10.00.12.png](806811354802421800_Zrzut_ekranu_2021-02-4_o_10.00.12.png?raw=true)

Reactions:  🇨 - 3 

___
Oliver: 

up

___
Maou: 

kurde tez mam to i nie wiem xd

___
Oliver: 

uniq na kolumnie

___
Oliver: 

unique

___
Oliver: 

w sumie

___
Emily: 

chociaż check też można

___
Emily: 





![unknown.png](806812719235727400_unknown.png?raw=true)

___
Oliver: 

true

___
Oliver: 

jest jedna odpowiedz

___
Lauren: 

czyli co tutaj?

___
Kyle: 

c

___
Jacob: 





![unknown.png](806817039946874960_unknown.png?raw=true)

___