### Channel name: 4-wskaż-prawdziwe-stweirdzenia-dotyczące-postaci-boyce-codda
___

Elizabeth: 





![unknown.png](806811427523788800_unknown.png?raw=true)

Reactions:  🇧 - 4 

___
Jack: 

Ja bym powiedział że B ale tu niech ktoś jeszcze zobaczy

___
Jack: 





![unknown.png](806812530949095454_unknown.png?raw=true)

___
Jack: 





![unknown.png](806812563476185108_unknown.png?raw=true)

___
Myles: 

też tak myślę

___
Haroldzina: 

d też wydaje mi się dobrze



![unknown.png](806815783875248148_unknown.png?raw=true)

___
Emily: 

jesteście pewni B?

___
Jack: 

Wygląda jakby D była poprawna

___
Emily: 

atrybut podstawowy to część klucza

___
Kyle: 

pozostałe są złe

___
Jack: 

D jednak może być ok

___
Lauren: 

ta

___
Lauren: 

D bylo dobrze

___
Lauren: 

XD

___
Jacob: 





![unknown.png](806816376516771850_unknown.png?raw=true)

___
Haroldzina: 

to chyba nie tyczy się wszystkich

___
Haroldzina: 

bo to jest tylko do tego, gdy jest bcnf i nie 3cnf

___
Haroldzina: 

z tego co rozumiem

___
Jacob: 

z opracowań z poprzednich lat wynika, że wykłady same sobie zaprzeczają w paru miejscach

Reactions:  💔 - 2 

___
Jacob: 

więc się tym nie przejmujcie

___
Hermione: 





![Zrzut_ekranu_2021-02-4_o_10.22.00.png](806816865871069204_Zrzut_ekranu_2021-02-4_o_10.22.00.png?raw=true)

___
Hermione: 

to prada

___
Hermione: 

prawda

___
Hermione: 

to przykład z wykładu

___