### Channel name: 8-jak-mozna-przy-pomocy-sql-uzyskac
___

Maou: 





![unknown.png](806811899890761738_unknown.png?raw=true)

Reactions:  🅱️ - 10 

___
Jacob: 





![unknown.png](806817124843782174_unknown.png?raw=true)

___