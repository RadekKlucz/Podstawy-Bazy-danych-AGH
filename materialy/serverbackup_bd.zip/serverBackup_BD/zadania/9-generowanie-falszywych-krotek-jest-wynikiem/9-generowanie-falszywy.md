### Channel name: 9-generowanie-fałszywych-krotek-jest-wynikiem
___

Thomas: 





![unknown.png](806812176996237322_unknown.png?raw=true)

Reactions:  🅰️ - 6 

___
Sophie: 

22. Czym są nadmierne krotki (błędne) i jak przeciwdziałać ich powstawaniu?
Są to krotki powstające podczas dekompozycji stratnej, które nie występowały w
oryginalnej relacji, zawierają fałszywe informacje i uniemożliwiają odtworzenie
oryginalnej tabeli. Aby nie powstawały nie należy przeprowadzać dekompozycji
stratnych.

___
Subaru Natsuki: 

ktoś coś?

___
Myles: 

ja bym dał D

___
Kyle: 

a złączenie nieaddytywne?

___
Jack: 

Czym jest złącze nieaddytywne?

___
Cooper: 

może to być to

___
Myles: 





![unknown.png](806813318739656734_unknown.png?raw=true)

___
Myles: 

może faktycznie

___
Lauren: 

czyli któro?

___
Jack: 

Patrząc po tym powyżej i wykładach to A wydaje się najbardziej sensowne

___
Jacob: 





![unknown.png](806816990727503882_unknown.png?raw=true)

___