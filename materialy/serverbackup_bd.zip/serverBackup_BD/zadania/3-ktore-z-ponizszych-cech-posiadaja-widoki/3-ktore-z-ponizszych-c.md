### Channel name: 3-które-z-poniższych-cech-posiadają-widoki
___

Maou: 





![unknown.png](806811447014719488_unknown.png?raw=true)

Reactions:  🇨 - 9 

___
Jacob: 





![unknown.png](806817189964546058_unknown.png?raw=true)

___