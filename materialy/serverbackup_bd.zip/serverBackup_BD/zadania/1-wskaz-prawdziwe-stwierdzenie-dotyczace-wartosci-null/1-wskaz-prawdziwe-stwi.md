### Channel name: 1-wskaż-prawdziwe-stwierdzenie-dotyczące-wartości-null
___

Jacob: 





![unknown.png](806811347811041330_unknown.png?raw=true)

Reactions:  🇩 - 5 

___
Haroldzina: 

nie B?

___
Haroldzina: 





![unknown.png](806813161859710977_unknown.png?raw=true)

___
Emily: 

zależne od implementacji

___
Emily: 

ms sql ignoruje null

___
Haroldzina: 

damn

___
Jacob: 





![unknown.png](806816738049130496_unknown.png?raw=true)

___