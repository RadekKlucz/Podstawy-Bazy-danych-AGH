### Channel name: 7-z-jakim-problemem-trzeba-się-uporać-przy-odwzorowaniu
___

Jacob: 





![unknown.png](806811786501160990_unknown.png?raw=true)

Reactions:  🅰️ - 5 

___
Jacob: 





![unknown.png](806816781406437386_unknown.png?raw=true)

___