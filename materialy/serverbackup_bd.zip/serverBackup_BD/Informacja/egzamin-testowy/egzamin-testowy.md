### Channel name: egzamin-testowy
___

Jacob: 





![unknown.png](806710543267921950_unknown.png?raw=true)

___
Jacob: 





![unknown.png](806710570115792916_unknown.png?raw=true)

___
Jacob: 





![unknown.png](806710601509634068_unknown.png?raw=true)

___
Jacob: 





![unknown.png](806710633831464960_unknown.png?raw=true)

___