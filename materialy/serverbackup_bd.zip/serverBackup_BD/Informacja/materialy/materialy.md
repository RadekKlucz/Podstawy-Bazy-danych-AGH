### Channel name: materiały
___

Hermione: 

wykłady

[bd-merged.pdf](806506102028107836_bd-merged.pdf)

___
Hermione: 

fiszki

[fiszki.pdf](806661036626542622_fiszki.pdf)

___
Hermione: 

opracowanie 2018/2019

[egzamin_opracowanie_2018_2019.pdf](806661583802728468_egzamin_opracowanie_2018_2019.pdf)

___
Hermione: 

opracowanie pytań 2016

[pbd_zygmunt_2016.pdf](806661894676938802_pbd_zygmunt_2016.pdf)

___
Hermione: 

opracowanie 2016/2017

[PBD_-_Opracowanie_pytan_z_egzaminu_2016_i_2017-2.pdf](806663599451275264_PBD_-_Opracowanie_pytan_z_egzaminu_2016_i_2017-2.pdf)

___